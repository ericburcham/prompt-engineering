My brother, Aaron, was 3 years old when I was nine.  His daughter, Jenny, is 27 years younger than he is.  I am now 46.  How old is Jenny.

Explain your reasoning step-by-step.









I have a remote control helicopter with a main rotor radius of 750mm.  In a hover, the main rotor spins at 2,100 RPM.  In a hover, how fast are the tips of the rotor blades moving in relation to the ground?  Express your answer in miles per hour.  Explain your thought process step-by-step.



This is wrong.  First, calculate the circumference of the rotor disk in meters.  Then multiply the circumference by the rotor RPM to calculate meters per minute.  Then convert meters per minute to miles per hour.