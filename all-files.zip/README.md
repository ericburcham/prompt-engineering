# prompt-engineering
A presentation on LLM prompt engineering with example prompts and funny images.
